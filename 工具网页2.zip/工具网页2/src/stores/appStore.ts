import { create } from 'zustand';
import { AppState, TabItem } from '../types';
import { HomeComponent } from '../components/common/HomeComponent';

interface AppStore extends AppState {
  toggleCollapsed: () => void;
  setActiveFirstLevel: (id: string) => void;
  setActiveSecondLevel: (id: string) => void;
  setActiveThirdLevel: (id: string) => void;
  addTab: (tab: Omit<TabItem, 'id'>) => void;
  removeTab: (id: string) => void;
  setActiveTab: (id: string) => void;
  setLanguage: (language: 'zh' | 'en') => void;
  setSearchQuery: (query: string) => void;
}

export const useAppStore = create<AppStore>((set, get) => ({
  collapsed: true, // 初始状态为折叠
  activeFirstLevel: '',
  activeSecondLevel: '',
  activeThirdLevel: '',
  secondLevelExpanded: false,
  tabs: [{ 
    id: 'home', 
    title: '首页', 
    path: '/home',
    component: HomeComponent,
    closable: false 
  }],
  activeTab: 'home',
  language: 'zh',
  searchQuery: '',
  
  // 只控制菜单的折叠/展开，不影响内容状态
  toggleCollapsed: () => set((state) => ({ 
    collapsed: !state.collapsed
  })),
  
  setActiveFirstLevel: (id: string) => {
    const state = get();
    
    if (state.activeFirstLevel === id && !state.collapsed) {
      // 再次点击同一一级导航且菜单已展开，则收起菜单
      set({ 
        collapsed: true
      });
    } else if (state.activeFirstLevel === id && state.collapsed) {
      // 点击同一一级导航且菜单已折叠，则展开菜单
      set({ 
        collapsed: false,
        secondLevelExpanded: true,
        activeTab: 'home' // 跳转到首页标签页
      });
    } else {
      // 点击新的一级导航，重置二级和三级导航，展开菜单
      set({ 
        activeFirstLevel: id,
        activeSecondLevel: '',
        activeThirdLevel: '',
        secondLevelExpanded: true,
        collapsed: false,
        activeTab: 'home' // 跳转到首页标签页
      });
    }
  },
  
  setActiveSecondLevel: (id: string) => set({ 
    activeSecondLevel: id,
    activeThirdLevel: '',
    secondLevelExpanded: true,
    activeTab: 'home' // 跳转到首页标签页
  }),
  
  setActiveThirdLevel: (id: string) => set({ activeThirdLevel: id }),
  
  addTab: (tab: Omit<TabItem, 'id'>) => {
    const existingTab = get().tabs.find(t => t.path === tab.path);
    if (existingTab) {
      set({ activeTab: existingTab.id });
      return;
    }

    const newTab = { ...tab, id: `${tab.path}-${Date.now()}` };
    set((state) => ({ 
      tabs: [...state.tabs, newTab],
      activeTab: newTab.id
    }));
  },
  
  removeTab: (id: string) => {
    if (id === 'home') return;
    
    set((state) => {
      const newTabs = state.tabs.filter(tab => tab.id !== id);
      const newActiveTab = state.activeTab === id 
        ? (newTabs[newTabs.length - 1]?.id || 'home')
        : state.activeTab;
      
      return { 
        tabs: newTabs, 
        activeTab: newActiveTab 
      };
    });
  },
  
  setActiveTab: (id: string) => set({ activeTab: id }),
  setLanguage: (language: 'zh' | 'en') => set({ language }),
  setSearchQuery: (query: string) => set({ searchQuery: query })
}));