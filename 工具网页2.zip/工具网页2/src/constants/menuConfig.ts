import { MenuItem } from '../types';

export const menuConfig: MenuItem[] = [
  {
    id: 'general',
    icon: '/icons/general.svg',
    title: '通用工具',
    children: [
      {
        id: 'excel',
        icon: '/icons/excel.svg',
        title: 'Excel 工具',
        children: [
          {
            id: 'convert-pdf',
            title: 'Excel 转 PDF',
          },
          {
            id: 'data-analysis', 
            title: '数据分析',
          }
        ]
      },
      {
        id: 'powerpoint',
        icon: '/icons/powerpoint.svg',
        title: 'PowerPoint 工具',
        children: [
          {
            id: 'convert-pdf',
            title: 'PPT 转 PDF',
          },
          {
            id: 'merge-presentation',
            title: '合并演示文稿',
          }
        ]
      },
      {
        id: 'word',
        icon: '/icons/word.svg',
        title: 'Word 工具',
        children: [
          {
            id: 'convert-pdf',
            title: 'Word 转 PDF',
          },
          {
            id: 'document-merge',
            title: '文档合并',
          }
        ]
      }
    ]
  },
  {
    id: 'procurement',
    icon: '/icons/procurement.svg',
    title: '采购管理',
    children: [
      {
        id: 'supplier-management',
        icon: '/icons/supplier.svg',
        title: '供应商管理',
        children: [
          {
            id: 'supplier-list',
            title: '供应商列表',
          },
          {
            id: 'supplier-evaluation',
            title: '供应商评估',
          }
        ]
      },
      {
        id: 'purchase-order',
        icon: '/icons/order.svg',
        title: '采购订单',
        children: [
          {
            id: 'create-order',
            title: '创建订单',
          },
          {
            id: 'order-tracking',
            title: '订单跟踪',
          }
        ]
      }
    ]
  }
];