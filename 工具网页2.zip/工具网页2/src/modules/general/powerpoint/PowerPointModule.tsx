import React from 'react';
import { Card, Alert } from 'antd';
import { useAppStore } from '../../../stores/appStore';

export const PowerPointModule: React.FC = () => {
  const { activeThirdLevel } = useAppStore();

  const getContent = () => {
    switch (activeThirdLevel) {
      case 'convert-pdf':
        return (
          <Card title="PPT 转 PDF">
            <div className="space-y-4">
              <Alert 
                message="功能开发中" 
                description="PPT转PDF功能正在紧张开发中，敬请期待！" 
                type="info" 
                showIcon 
              />
              <div className="p-4 border border-dashed border-gray-300 rounded-lg text-center">
                <p className="text-gray-500">上传 PPT 文件区域</p>
              </div>
            </div>
          </Card>
        );
      case 'merge-presentation':
        return (
          <Card title="合并演示文稿">
            <div className="space-y-4">
              <Alert 
                message="功能开发中" 
                description="演示文稿合并功能正在开发中。" 
                type="info" 
                showIcon 
              />
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 border border-dashed border-gray-300 rounded-lg text-center">
                  <p>PPT 文件 1</p>
                </div>
                <div className="p-4 border border-dashed border-gray-300 rounded-lg text-center">
                  <p>PPT 文件 2</p>
                </div>
              </div>
            </div>
          </Card>
        );
      default:
        return (
          <Card>
            <div className="text-center py-12 text-gray-500">
              <p className="text-lg">请选择 PowerPoint 功能</p>
            </div>
          </Card>
        );
    }
  };

  return (
    <div className="p-6">
      {getContent()}
    </div>
  );
};