import React from 'react';
import { Menu, Card } from 'antd';
import { useAppStore } from '../../../stores/appStore';
import { ExcelConvertPDF } from './ExcelConvertPDF';
import { ExcelDataAnalysis } from './ExcelDataAnalysis';

const componentMap = {
  'convert-pdf': ExcelConvertPDF,
  'data-analysis': ExcelDataAnalysis,
};

export const ExcelModule: React.FC = () => {
  const { activeThirdLevel, setActiveThirdLevel, addTab } = useAppStore();

  const thirdLevelItems = [
    { 
      key: 'convert-pdf', 
      label: 'Excel 转 PDF', 
    },
    { 
      key: 'data-analysis', 
      label: '数据分析', 
    },
  ];

  const handleMenuClick = (key: string) => {
    const item = thirdLevelItems.find(i => i.key === key);
    if (item) {
      setActiveThirdLevel(key);
      const Component = componentMap[key as keyof typeof componentMap];
      if (Component) {
        addTab({
          title: item.label,
          path: `/general/excel/${key}`,
          component: Component,
          closable: true
        });
      }
    }
  };

  const CurrentComponent = activeThirdLevel ? componentMap[activeThirdLevel as keyof typeof componentMap] : null;

  return (
    <div className="flex h-full min-h-[600px]">
      {/* 三级导航菜单 */}
      <div className="w-64 bg-gray-50 border-r border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <h3 className="font-semibold text-gray-800">Excel 工具</h3>
        </div>
        <Menu
          mode="vertical"
          selectedKeys={[activeThirdLevel]}
          items={thirdLevelItems.map(item => ({
            key: item.key,
            label: item.label
          }))}
          onClick={({ key }) => handleMenuClick(key)}
          className="border-none"
        />
      </div>
      
      {/* 三级内容区域 */}
      <div className="flex-1 p-6 bg-white">
        {CurrentComponent ? (
          <CurrentComponent />
        ) : (
          <Card className="h-full flex items-center justify-center">
            <div className="text-center text-gray-500">
              <p className="text-lg">请选择左侧功能开始使用</p>
              <p className="text-sm mt-2">选择具体的 Excel 工具功能</p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};