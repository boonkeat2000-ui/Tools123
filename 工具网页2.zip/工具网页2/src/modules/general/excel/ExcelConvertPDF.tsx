import React, { useState } from 'react';
import { Card, Button, Upload, message, Progress, Space } from 'antd';
import { UploadOutlined, DownloadOutlined } from '@ant-design/icons';
import type { UploadProps } from 'antd';

const { Dragger } = Upload;

export const ExcelConvertPDF: React.FC = () => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const props: UploadProps = {
    name: 'file',
    multiple: false,
    accept: '.xlsx,.xls',
    action: '/api/convert/excel-to-pdf',
    onChange(info) {
      const { status } = info.file;
      if (status === 'uploading') {
        setUploading(true);
        setProgress(30);
      }
      if (status === 'done') {
        setProgress(100);
        message.success(`${info.file.name} 转换成功`);
        setUploading(false);
      } else if (status === 'error') {
        message.error(`${info.file.name} 转换失败`);
        setUploading(false);
        setProgress(0);
      }
    },
  };

  const handleDownload = () => {
    // 模拟下载
    message.success('开始下载转换后的PDF文件');
  };

  return (
    <div className="p-6">
      <Card title="Excel 转 PDF" className="max-w-4xl mx-auto">
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium mb-2">上传 Excel 文件</h3>
            <p className="text-gray-600 mb-4">
              支持 .xlsx 和 .xls 格式的文件转换
            </p>
          </div>

          <Dragger {...props} disabled={uploading}>
            <div className="p-8 text-center">
              <UploadOutlined className="text-4xl text-blue-500 mb-4" />
              <p className="text-lg">点击或拖拽文件到此区域上传</p>
              <p className="text-gray-500 mt-2">
                支持单个 Excel 文件转换
              </p>
            </div>
          </Dragger>

          {uploading && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>转换进度</span>
                <span>{progress}%</span>
              </div>
              <Progress percent={progress} status="active" />
            </div>
          )}

          {progress === 100 && (
            <div className="text-center">
              <Button 
                type="primary" 
                icon={<DownloadOutlined />}
                size="large"
                onClick={handleDownload}
              >
                下载 PDF 文件
              </Button>
            </div>
          )}

          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium text-blue-800 mb-2">使用说明：</h4>
            <ul className="text-blue-700 list-disc list-inside space-y-1">
              <li>上传的 Excel 文件大小不能超过 50MB</li>
              <li>转换过程可能需要几分钟时间，请耐心等待</li>
              <li>转换后的 PDF 文件将保持原始格式和布局</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
};