import React, { useState } from 'react';
import { Card, Button, Upload, Table, Statistic, Row, Col } from 'antd';
import { UploadOutlined, BarChartOutlined } from '@ant-design/icons';
import type { UploadProps, TableColumnsType } from 'antd';

interface DataType {
  key: string;
  name: string;
  department: string;
  salary: number;
  performance: number;
}

export const ExcelDataAnalysis: React.FC = () => {
  const [data, setData] = useState<DataType[]>([]);
  const [analyzing, setAnalyzing] = useState(false);

  const columns: TableColumnsType<DataType> = [
    {
      title: '姓名',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '部门',
      dataIndex: 'department',
      key: 'department',
    },
    {
      title: '薪资',
      dataIndex: 'salary',
      key: 'salary',
      render: (value) => `¥${value.toLocaleString()}`,
    },
    {
      title: '绩效',
      dataIndex: 'performance',
      key: 'performance',
      render: (value) => `${value}%`,
    },
  ];

  const uploadProps: UploadProps = {
    name: 'file',
    accept: '.xlsx,.xls',
    beforeUpload: (file) => {
      // 模拟数据分析
      setAnalyzing(true);
      setTimeout(() => {
        const mockData: DataType[] = [
          { key: '1', name: '张三', department: '技术部', salary: 15000, performance: 85 },
          { key: '2', name: '李四', department: '市场部', salary: 12000, performance: 92 },
          { key: '3', name: '王五', department: '财务部', salary: 13000, performance: 78 },
          { key: '4', name: '赵六', department: '技术部', salary: 16000, performance: 88 },
        ];
        setData(mockData);
        setAnalyzing(false);
      }, 2000);
      return false; // 阻止自动上传
    },
  };

  const totalSalary = data.reduce((sum, item) => sum + item.salary, 0);
  const avgPerformance = data.length > 0 
    ? data.reduce((sum, item) => sum + item.performance, 0) / data.length 
    : 0;

  return (
    <div className="p-6">
      <Card title="Excel 数据分析" className="max-w-6xl mx-auto">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-medium">上传 Excel 数据进行智能分析</h3>
              <p className="text-gray-600">系统将自动识别数据并进行统计分析</p>
            </div>
            <Upload {...uploadProps}>
              <Button 
                icon={<UploadOutlined />} 
                size="large"
                loading={analyzing}
              >
                {analyzing ? '分析中...' : '上传 Excel 文件'}
              </Button>
            </Upload>
          </div>

          {data.length > 0 && (
            <>
              <Row gutter={16} className="mb-6">
                <Col span={6}>
                  <Card>
                    <Statistic
                      title="总记录数"
                      value={data.length}
                      suffix="条"
                    />
                  </Card>
                </Col>
                <Col span={6}>
                  <Card>
                    <Statistic
                      title="总薪资"
                      value={totalSalary}
                      prefix="¥"
                      formatter={(value) => value.toLocaleString()}
                    />
                  </Card>
                </Col>
                <Col span={6}>
                  <Card>
                    <Statistic
                      title="平均绩效"
                      value={avgPerformance}
                      precision={1}
                      suffix="%"
                    />
                  </Card>
                </Col>
                <Col span={6}>
                  <Card>
                    <Statistic
                      title="部门数量"
                      value={new Set(data.map(item => item.department)).size}
                      suffix="个"
                    />
                  </Card>
                </Col>
              </Row>

              <Card 
                title="数据详情" 
                extra={
                  <Button icon={<BarChartOutlined />}>
                    生成图表报告
                  </Button>
                }
              >
                <Table 
                  columns={columns} 
                  dataSource={data}
                  pagination={{ pageSize: 10 }}
                  scroll={{ x: 800 }}
                />
              </Card>
            </>
          )}

          {data.length === 0 && !analyzing && (
            <div className="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg">
              <BarChartOutlined className="text-4xl text-gray-400 mb-4" />
              <p className="text-gray-500 text-lg">请上传 Excel 文件开始数据分析</p>
            </div>
          )}

          {analyzing && (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
              <p className="text-gray-600">正在分析数据，请稍候...</p>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};