import React from 'react';
import { Card, Alert, Progress } from 'antd';
import { useAppStore } from '../../../stores/appStore';

export const WordModule: React.FC = () => {
  const { activeThirdLevel } = useAppStore();

  const getContent = () => {
    switch (activeThirdLevel) {
      case 'convert-pdf':
        return (
          <Card title="Word 转 PDF" className="max-w-2xl mx-auto">
            <div className="space-y-6">
              <Alert
                message="转换说明"
                description="将 Word 文档转换为 PDF 格式，保持原始格式和布局。"
                type="info"
                showIcon
              />
              
              <div className="text-center p-8 border-2 border-dashed border-gray-300 rounded-lg">
                <p className="text-gray-500 mb-4">拖拽 Word 文件到此区域或点击上传</p>
                <p className="text-sm text-gray-400">支持 .doc, .docx 格式</p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>转换准备就绪</span>
                  <span>0%</span>
                </div>
                <Progress percent={0} status="active" />
              </div>
            </div>
          </Card>
        );
      case 'document-merge':
        return (
          <Card title="文档合并">
            <div className="space-y-4">
              <Alert 
                message="批量文档合并" 
                description="将多个 Word 文档合并为一个文档。" 
                type="success" 
                showIcon 
              />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="p-4 border border-dashed border-gray-300 rounded-lg text-center">
                    <p>文档 {i}</p>
                    <p className="text-sm text-gray-500">点击上传</p>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        );
      default:
        return (
          <Card>
            <div className="text-center py-12 text-gray-500">
              <p className="text-lg">请选择 Word 工具功能</p>
              <p className="text-sm mt-2">文档转换、合并等实用功能</p>
            </div>
          </Card>
        );
    }
  };

  return (
    <div className="p-6">
      {getContent()}
    </div>
  );
};