import React from 'react';
import { Card, Table, Tag, Button, Space } from 'antd';
import { EyeOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import type { TableColumnsType } from 'antd';
import { useAppStore } from '../../stores/appStore';

interface SupplierData {
  key: string;
  name: string;
  contact: string;
  phone: string;
  email: string;
  status: 'active' | 'inactive';
  rating: number;
}

export const ProcurementModule: React.FC = () => {
  const { activeThirdLevel } = useAppStore();

  const supplierColumns: TableColumnsType<SupplierData> = [
    {
      title: '供应商名称',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '联系人',
      dataIndex: 'contact',
      key: 'contact',
    },
    {
      title: '电话',
      dataIndex: 'phone',
      key: 'phone',
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status) => (
        <Tag color={status === 'active' ? 'green' : 'red'}>
          {status === 'active' ? '活跃' : '停用'}
        </Tag>
      ),
    },
    {
      title: '评级',
      dataIndex: 'rating',
      key: 'rating',
      render: (rating) => `${rating}/5`,
    },
    {
      title: '操作',
      key: 'action',
      render: (_, record) => (
        <Space size="small">
          <Button type="link" icon={<EyeOutlined />} size="small">
            查看
          </Button>
          <Button type="link" icon={<EditOutlined />} size="small">
            编辑
          </Button>
          <Button type="link" icon={<DeleteOutlined />} size="small" danger>
            删除
          </Button>
        </Space>
      ),
    },
  ];

  const supplierData: SupplierData[] = [
    {
      key: '1',
      name: 'ABC 科技有限公司',
      contact: '张经理',
      phone: '138-0013-8000',
      email: 'zhang@abc.com',
      status: 'active',
      rating: 4,
    },
    {
      key: '2',
      name: 'XYZ 设备有限公司',
      contact: '李总监',
      phone: '139-0013-9000',
      email: 'li@xyz.com',
      status: 'active',
      rating: 5,
    },
  ];

  const getContent = () => {
    switch (activeThirdLevel) {
      case 'supplier-list':
        return (
          <Card 
            title="供应商列表" 
            extra={
              <Button type="primary">
                添加供应商
              </Button>
            }
          >
            <Table 
              columns={supplierColumns} 
              dataSource={supplierData}
              pagination={{ pageSize: 10 }}
            />
          </Card>
        );
      case 'supplier-evaluation':
        return (
          <Card title="供应商评估">
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">4.5</div>
                    <div className="text-gray-600">平均评分</div>
                  </div>
                </Card>
                <Card>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">15</div>
                    <div className="text-gray-600">活跃供应商</div>
                  </div>
                </Card>
                <Card>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">2</div>
                    <div className="text-gray-600">待评估</div>
                  </div>
                </Card>
              </div>
            </div>
          </Card>
        );
      case 'create-order':
        return (
          <Card title="创建采购订单">
            <div className="max-w-2xl space-y-4">
              <Alert
                message="新订单创建"
                description="填写采购订单详细信息"
                type="info"
                showIcon
              />
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 border border-gray-200 rounded-lg">
                  <label className="block text-sm font-medium text-gray-700">产品名称</label>
                  <input type="text" className="mt-1 block w-full border border-gray-300 rounded-md p-2" />
                </div>
                <div className="p-4 border border-gray-200 rounded-lg">
                  <label className="block text-sm font-medium text-gray-700">数量</label>
                  <input type="number" className="mt-1 block w-full border border-gray-300 rounded-md p-2" />
                </div>
              </div>
              <Button type="primary" size="large">
                提交订单
              </Button>
            </div>
          </Card>
        );
      case 'order-tracking':
        return (
          <Card title="订单跟踪">
            <div className="space-y-4">
              <Alert
                message="订单状态跟踪"
                description="实时监控采购订单执行状态"
                type="success"
                showIcon
              />
              <div className="space-y-2">
                {[
                  { status: 'completed', text: '订单创建', time: '2024-01-15 10:00' },
                  { status: 'completed', text: '供应商确认', time: '2024-01-15 14:30' },
                  { status: 'current', text: '生产制造', time: '进行中' },
                  { status: 'pending', text: '物流运输', time: '待开始' },
                  { status: 'pending', text: '收货确认', time: '待开始' },
                ].map((step, index) => (
                  <div key={index} className="flex items-center space-x-4 p-3 border border-gray-200 rounded-lg">
                    <div className={`w-3 h-3 rounded-full ${
                      step.status === 'completed' ? 'bg-green-500' :
                      step.status === 'current' ? 'bg-blue-500' : 'bg-gray-300'
                    }`}></div>
                    <div className="flex-1">
                      <div className="font-medium">{step.text}</div>
                      <div className="text-sm text-gray-500">{step.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        );
      default:
        return (
          <Card>
            <div className="text-center py-12 text-gray-500">
              <p className="text-lg">请选择采购管理功能</p>
              <p className="text-sm mt-2">供应商管理、订单处理等业务功能</p>
            </div>
          </Card>
        );
    }
  };

  return (
    <div className="p-6">
      {getContent()}
    </div>
  );
};