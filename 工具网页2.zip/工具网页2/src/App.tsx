import React from 'react';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import enUS from 'antd/locale/en_US';
import { AppLayout } from './components/layout/AppLayout';
import { useAppStore } from './stores/appStore';
import './styles/globals.css';

const App: React.FC = () => {
  const { language } = useAppStore();

  return (
    <ConfigProvider locale={language === 'zh' ? zhCN : enUS}>
      <div className="App">
        <AppLayout />
      </div>
    </ConfigProvider>
  );
};

export default App;