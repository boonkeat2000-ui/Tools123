import React from 'react';
import { Breadcrumb as AntBreadcrumb } from 'antd';
import { useAppStore } from '../../stores/appStore';
import { menuConfig } from '../../constants/menuConfig';

export const Breadcrumb: React.FC = () => {
  const { activeTab, tabs } = useAppStore();

  // 获取当前激活标签页的面包屑信息
  const getBreadcrumbItems = () => {
    // 如果当前是首页标签，始终显示首页
    if (activeTab === 'home') {
      return [{ title: '首页' }];
    }

    // 获取当前激活的标签页
    const currentTab = tabs.find(tab => tab.id === activeTab);
    if (!currentTab) {
      return [{ title: '首页' }];
    }

    // 解析路径获取层级信息
    const pathParts = currentTab.path.split('/').filter(Boolean);
    
    if (pathParts.length === 0) {
      return [{ title: '首页' }];
    }

    const items = [{ title: '首页' }];

    // 根据路径构建面包屑
    if (pathParts.length >= 1) {
      const firstLevel = menuConfig.find(item => item.id === pathParts[0]);
      if (firstLevel) {
        items.push({ title: firstLevel.title });
      }
    }

    if (pathParts.length >= 2) {
      const firstLevel = menuConfig.find(item => item.id === pathParts[0]);
      if (firstLevel?.children) {
        const secondLevel = firstLevel.children.find(item => item.id === pathParts[1]);
        if (secondLevel) {
          items.push({ title: secondLevel.title });
        }
      }
    }

    if (pathParts.length >= 3) {
      const firstLevel = menuConfig.find(item => item.id === pathParts[0]);
      if (firstLevel?.children) {
        const secondLevel = firstLevel.children.find(item => item.id === pathParts[1]);
        if (secondLevel?.children) {
          const thirdLevel = secondLevel.children.find(item => item.id === pathParts[2]);
          if (thirdLevel) {
            items.push({ title: thirdLevel.title });
          }
        }
      }
    }

    return items;
  };

  const breadcrumbItems = getBreadcrumbItems();

  return (
    <AntBreadcrumb
      items={breadcrumbItems}
      className="text-sm"
    />
  );
};