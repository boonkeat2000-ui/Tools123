import React from 'react';
import { Input } from 'antd';
import { SearchOutlined } from '@ant-design/icons';
import { useAppStore } from '../../stores/appStore';

const { Search } = Input;

export const SearchBar: React.FC = () => {
  const { language, setSearchQuery } = useAppStore();

  const placeholder = language === 'zh' ? '搜索功能...' : 'Search...';

  const handleSearch = (value: string) => {
    setSearchQuery(value);
    console.log('Search:', value);
  };

  return (
    <Search
      placeholder={placeholder}
      onSearch={handleSearch}
      onChange={(e) => setSearchQuery(e.target.value)}
      style={{ width: 250 }}
      size="middle"
      allowClear
      enterButton={<SearchOutlined />}
    />
  );
};