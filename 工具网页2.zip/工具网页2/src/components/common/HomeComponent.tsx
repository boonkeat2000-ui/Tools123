import React from 'react';

export const HomeComponent: React.FC = () => {
  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">
          欢迎使用 Tools System
        </h1>
        <p className="text-lg text-gray-600 mb-8">
          请从左侧导航菜单选择功能模块开始使用
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          <div className="p-6 bg-white border border-gray-200 rounded-lg shadow-sm">
            <div className="text-blue-600 text-sm font-semibold mb-2">第一步</div>
            <div className="text-gray-900 font-medium mb-2">选择一级菜单</div>
            <div className="text-gray-500 text-sm">点击左侧图标选择功能大类</div>
          </div>
          <div className="p-6 bg-white border border-gray-200 rounded-lg shadow-sm">
            <div className="text-green-600 text-sm font-semibold mb-2">第二步</div>
            <div className="text-gray-900 font-medium mb-2">选择二级菜单</div>
            <div className="text-gray-500 text-sm">在右侧选择具体的功能模块</div>
          </div>
          <div className="p-6 bg-white border border-gray-200 rounded-lg shadow-sm">
            <div className="text-purple-600 text-sm font-semibold mb-2">第三步</div>
            <div className="text-gray-900 font-medium mb-2">使用功能</div>
            <div className="text-gray-500 text-sm">点击功能卡片打开对应页面</div>
          </div>
        </div>
      </div>
    </div>
  );
};