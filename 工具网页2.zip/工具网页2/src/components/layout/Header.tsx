import React from 'react';
import { Layout } from 'antd';
import { Breadcrumb } from '../common/Breadcrumb';
import { SearchBar } from '../common/SearchBar';
import { LanguageSwitcher } from '../common/LanguageSwitcher';

const { Header: AntHeader } = Layout;

export const Header: React.FC = () => {
  return (
    <AntHeader className="bg-white border-b border-gray-200 px-6 flex items-center justify-between shadow-sm">
      <div className="flex items-center flex-1">
        <Breadcrumb />
      </div>
      <div className="flex items-center space-x-4">
        <SearchBar />
        <LanguageSwitcher />
      </div>
    </AntHeader>
  );
};