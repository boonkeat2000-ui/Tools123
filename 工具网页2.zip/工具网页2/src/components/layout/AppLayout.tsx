import React from 'react';
import { Layout } from 'antd';
import { Header } from './Header';
import { Navigation } from './Navigation';
import { ContentArea } from './ContentArea';
import { useAppStore } from '../../stores/appStore';

const { Sider } = Layout;

export const AppLayout: React.FC = () => {
  const collapsed = useAppStore((state) => state.collapsed);

  return (
    <Layout className="h-screen overflow-hidden bg-gray-50">
      <Sider 
        width={340}
        collapsedWidth={80}
        collapsed={collapsed}
        className="bg-white shadow-xl" // 移除边框，使用阴影
        trigger={null}
        collapsible
      >
        <Navigation />
      </Sider>
      
      <Layout className="bg-gray-50">
        <Header />
        <ContentArea />
      </Layout>
    </Layout>
  );
};