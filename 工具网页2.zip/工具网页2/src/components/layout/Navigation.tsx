import React from 'react';
import { CompanyLogo } from './CompanyLogo';
import { FirstLevelMenu } from './FirstLevelMenu';
import { SecondLevelMenu } from './SecondLevelMenu';
import { CollapseButton } from './CollapseButton';

export const Navigation: React.FC = () => {
  return (
    <div className="flex flex-col h-full">
      <CompanyLogo />
      <div className="flex flex-1 overflow-hidden">
        {/* 一级导航固定宽度 */}
        <FirstLevelMenu />
        {/* 二级导航占据剩余空间 */}
        <div className="flex-1 flex">
          <SecondLevelMenu />
        </div>
      </div>
      <CollapseButton />
    </div>
  );
};