import React from 'react';
import { Button } from 'antd';
import { useAppStore } from '../../stores/appStore';

export const CollapseButton: React.FC = () => {
  const { collapsed, toggleCollapsed } = useAppStore();

  return (
    <div className="collapse-button-area p-4">
      <Button
        type="text"
        onClick={toggleCollapsed}
        className="w-full flex items-center justify-center h-5 hover:bg-white/50 rounded-xl transition-all duration-300 border border-transparent hover:border-gray-200"
      >
        <div className={`w-5 h-5 transition-all duration-300 ${collapsed ? '' : 'rotate-180'}`}>
          <svg viewBox="0 0 24 24" fill="currentColor" className="text-gray-600">
            <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/>
          </svg>
        </div>
        {!collapsed && (
          <span className="ml-3 text-sm font-medium text-gray-700">收起菜单</span>
        )}
      </Button>
    </div>
  );
};