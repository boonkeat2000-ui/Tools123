import React from 'react';
import { Tabs } from 'antd';
import { HomeOutlined } from '@ant-design/icons';
import { useAppStore } from '../../stores/appStore';

export const TabSystem: React.FC = () => {
  const { tabs, activeTab, setActiveTab, removeTab } = useAppStore();

  const handleTabChange = (key: string) => {
    setActiveTab(key);
  };

  const handleTabEdit = (targetKey: string | React.MouseEvent | React.KeyboardEvent, action: 'add' | 'remove') => {
    if (action === 'remove') {
      removeTab(targetKey as string);
    }
  };

  const tabItems = tabs.map(tab => ({
    key: tab.id,
    label: (
      <div className="flex items-center space-x-2 px-1">
        {tab.id === 'home' && <HomeOutlined className="text-blue-500" />}
        <span className="text-sm">{tab.title}</span>
      </div>
    ),
    closable: tab.closable,
  }));

  return (
    <div className="border-b border-gray-200 bg-white">
      <Tabs
        type="editable-card"
        activeKey={activeTab}
        onChange={handleTabChange}
        onEdit={handleTabEdit}
        items={tabItems}
        hideAdd
        size="small"
        className="px-4"
        tabBarStyle={{ margin: 0 }}
      />
    </div>
  );
};