import React from 'react';
import { Menu } from 'antd';
import { useAppStore } from '../../stores/appStore';
import { menuConfig } from '../../constants/menuConfig';

export const SecondLevelMenu: React.FC = () => {
    const {
        activeFirstLevel,
        activeSecondLevel,
        setActiveSecondLevel,
        collapsed,
        secondLevelExpanded
    } = useAppStore();

    const currentMenu = menuConfig.find(item => item.id === activeFirstLevel);
    const secondLevelItems = currentMenu?.children || [];

    // 如果没有选择一级导航或菜单处于折叠状态，不显示二级导航
    if (collapsed || !currentMenu || !secondLevelExpanded) {
        return null;
    }

    return (
        <div className="flex-1 flex flex-col">
            {/* 一级选项标题 - 使用指定背景样式 */}
            <div
                className="h-12 flex items-center px-4 border-b border-gray-200"
                style={{
                    background: 'linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%)'
                }}
            >
                <h3 className="text-lg font-semibold text-gray-800">
                    {currentMenu.title}
                </h3>
            </div>

            {/* 二级导航选项区域 - 使用渐变背景 */}
            <div
                className="flex-1 overflow-y-auto custom-scrollbar py-3"
                style={{
                    background: 'linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%)'
                }}
            >
                <Menu
                    mode="vertical"
                    selectedKeys={[activeSecondLevel]}
                    className="border-none bg-transparent"
                    items={secondLevelItems.map(item => ({
                        key: item.id,
                        icon: (
                            <div className="w-5 h-5 flex items-center justify-center mr-3 flex-shrink-0">
                                <img src={item.icon} alt={item.title} className="w-4 h-4" />
                            </div>
                        ),
                        label: item.title, // 直接使用字符串，让 Ant Design 处理文本渲染
                        style: {
                            height: '44px',
                            display: 'flex',
                            alignItems: 'center',
                            margin: '6px 12px',
                            borderRadius: '8px',
                            paddingLeft: '16px',
                            justifyContent: 'flex-start',
                            background: 'linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%)',
                            border: '1.5px solid #e2e8f0'
                        }
                    }))}
                    onClick={({ key }) => setActiveSecondLevel(key)}
                />
            </div>
        </div>
    );
};