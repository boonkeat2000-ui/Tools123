import React from 'react';
import { Layout } from 'antd';
import { TabSystem } from './TabSystem';
import { ThirdLevelContent } from './ThirdLevelContent';

const { Content } = Layout;

export const ContentArea: React.FC = () => {
  return (
    <Content className="bg-white flex flex-col overflow-hidden">
      <TabSystem />
      <div className="flex-1 overflow-auto">
        <ThirdLevelContent />
      </div>
    </Content>
  );
};