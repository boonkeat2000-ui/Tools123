import React from 'react';
import { Menu, Tooltip } from 'antd';
import { useAppStore } from '../../stores/appStore';
import { menuConfig } from '../../constants/menuConfig';

export const FirstLevelMenu: React.FC = () => {
  const { 
    activeFirstLevel, 
    setActiveFirstLevel, 
    collapsed 
  } = useAppStore();

  return (
    <div className="first-level-menu w-20 border-r border-gray-200 bg-gray-50">
      <Menu
        mode="vertical"
        selectedKeys={[activeFirstLevel]}
        className="border-none bg-transparent h-full"
        items={menuConfig.map(item => ({
          key: item.id,
          icon: (
            <Tooltip 
              title={item.title} 
              placement="right"
              mouseEnterDelay={0.3}
            >
              <div className="w-full h-full flex items-center justify-center p-0 m-0">
                <img 
                  src={item.icon} 
                  alt={item.title} 
                  className="w-6 h-6"
                />
              </div>
            </Tooltip>
          ),
          label: null, // 完全移除文本标签
          style: {
            height: '56px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '6px 12px',
            borderRadius: '12px',
            padding: 0
          }
        }))}
        onClick={({ key }) => setActiveFirstLevel(key)}
      />
    </div>
  );
};