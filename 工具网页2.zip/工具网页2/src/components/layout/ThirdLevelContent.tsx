import React from 'react';
import { Card } from 'antd';
import { useAppStore } from '../../stores/appStore';
import { menuConfig } from '../../constants/menuConfig';
import { ExcelConvertPDF } from '../../modules/general/excel/ExcelConvertPDF';
import { ExcelDataAnalysis } from '../../modules/general/excel/ExcelDataAnalysis';
import { PowerPointModule } from '../../modules/general/powerpoint/PowerPointModule';
import { WordModule } from '../../modules/general/word/WordModule';
import { ProcurementModule } from '../../modules/procurement/ProcurementModule';

// 三级功能组件映射
const thirdLevelComponents: { [key: string]: React.ComponentType } = {
  // General -> Excel
  'excel-convert-pdf': ExcelConvertPDF,
  'excel-data-analysis': ExcelDataAnalysis,
  
  // General -> PowerPoint
  'powerpoint-convert-pdf': PowerPointModule,
  'powerpoint-merge-presentation': PowerPointModule,
  
  // General -> Word
  'word-convert-pdf': WordModule,
  'word-document-merge': WordModule,
  
  // Procurement -> Supplier Management
  'supplier-list': ProcurementModule,
  'supplier-evaluation': ProcurementModule,
  
  // Procurement -> Purchase Order
  'create-order': ProcurementModule,
  'order-tracking': ProcurementModule,
};

export const ThirdLevelContent: React.FC = () => {
  const { 
    activeFirstLevel, 
    activeSecondLevel, 
    addTab,
    tabs,
    activeTab
  } = useAppStore();

  // 获取当前的三级导航项
  const getThirdLevelItems = () => {
    const firstLevel = menuConfig.find(item => item.id === activeFirstLevel);
    if (!firstLevel) return [];

    const secondLevel = firstLevel.children?.find(item => item.id === activeSecondLevel);
    if (!secondLevel) return [];

    return secondLevel.children || [];
  };

  const thirdLevelItems = getThirdLevelItems();

  // 处理三级导航项点击
  const handleThirdLevelClick = (item: any) => {
    const componentKey = `${activeSecondLevel}-${item.id}`;
    const Component = thirdLevelComponents[componentKey];
    
    if (Component) {
      addTab({
        title: item.title,
        path: `/${activeFirstLevel}/${activeSecondLevel}/${item.id}`,
        component: Component,
        closable: true
      });
    }
  };

  // 如果是首页标签，显示三级导航
  if (activeTab === 'home' && thirdLevelItems.length > 0) {
    return (
      <div className="p-6 w-full">
        <Card 
          title="功能导航" 
          className="w-full max-w-none"
          bodyStyle={{ padding: '24px' }}
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 w-full">
            {thirdLevelItems.map((item, index) => (
              <div
                key={item.id}
                className="p-6 border-2 border-gray-100 rounded-xl hover:border-blue-300 hover:shadow-lg cursor-pointer transition-all duration-300 bg-white group"
                onClick={() => handleThirdLevelClick(item)}
                style={{
                  animationDelay: `${index * 100}ms`,
                }}
              >
                <div className="text-left">
                  <div className="flex items-start mb-3">
                    <div className="flex-shrink-0 w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center mr-4 group-hover:bg-blue-100 transition-colors">
                      <div className="w-6 h-6 bg-blue-500 rounded group-hover:bg-blue-600 transition-colors"></div>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 text-lg group-hover:text-blue-700 transition-colors mb-2">
                        {item.title}
                      </h3>
                      <p className="text-sm text-gray-500 group-hover:text-gray-600 transition-colors">
                        点击打开功能页面
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {thirdLevelItems.length === 0 && (
            <div className="text-center py-12 text-gray-500 w-full">
              <p className="text-lg">请选择二级菜单</p>
            </div>
          )}
        </Card>
      </div>
    );
  }

  // 获取当前激活的标签页组件
  const activeTabData = tabs.find(tab => tab.id === activeTab);
  if (activeTabData && activeTab !== 'home') {
    const Component = activeTabData.component;
    return <Component />;
  }

  // 默认显示欢迎信息
  return (
    <div className="p-6 w-full">
      <Card className="w-full max-w-none">
        <div className="text-center py-12 w-full">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            欢迎使用 Tools System
          </h1>
          <p className="text-gray-600 mb-8">
            请从左侧菜单选择功能模块开始使用
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto w-full">
            <div className="p-6 bg-blue-50 rounded-lg border border-blue-100">
              <div className="text-blue-600 font-semibold mb-2 text-left">第一步</div>
              <div className="text-gray-900 font-medium mb-2 text-left">选择一级菜单</div>
              <div className="text-gray-500 text-sm text-left">点击左侧图标选择功能大类</div>
            </div>
            <div className="p-6 bg-green-50 rounded-lg border border-green-100">
              <div className="text-green-600 font-semibold mb-2 text-left">第二步</div>
              <div className="text-gray-900 font-medium mb-2 text-left">选择二级菜单</div>
              <div className="text-gray-500 text-sm text-left">在右侧选择具体的功能模块</div>
            </div>
            <div className="p-6 bg-purple-50 rounded-lg border border-purple-100">
              <div className="text-purple-600 font-semibold mb-2 text-left">第三步</div>
              <div className="text-gray-900 font-medium mb-2 text-left">使用功能</div>
              <div className="text-gray-500 text-sm text-left">点击功能卡片打开对应页面</div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};