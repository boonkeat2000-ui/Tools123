import React from 'react';
import { useAppStore } from '../../stores/appStore';

export const CompanyLogo: React.FC = () => {
  const collapsed = useAppStore((state) => state.collapsed);

  return (
    <div className="company-logo-area h-16 flex items-center p-4">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
          <img 
            src="/icons/company-logo.svg" 
            alt="Company Logo" 
            className="w-6 h-6 filter brightness-0 invert"
          />
        </div>
        {!collapsed && (
          <div className="flex flex-col">
            <span className="text-white font-bold text-lg leading-tight">
              Tools System
            </span>
            <span className="text-blue-100 text-xs font-medium">
              Enterprise Platform
            </span>
          </div>
        )}
      </div>
    </div>
  );
};