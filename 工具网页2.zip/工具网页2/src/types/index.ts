import { ComponentType } from 'react';

export interface MenuItem {
  id: string;
  icon: string;
  title: string;
  children?: MenuItem[];
  component?: ComponentType;
}

export interface TabItem {
  id: string;
  title: string;
  path: string;
  component: ComponentType;
  closable: boolean;
}

export interface AppState {
  collapsed: boolean;
  activeFirstLevel: string;
  activeSecondLevel: string;
  activeThirdLevel: string;
  secondLevelExpanded: boolean; // 新增
  tabs: TabItem[];
  activeTab: string;
  language: 'zh' | 'en';
  searchQuery: string;
}